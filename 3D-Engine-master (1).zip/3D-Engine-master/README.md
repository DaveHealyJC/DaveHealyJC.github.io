# 3D-Engine
Javascript 3D engine created through 2D context API

Accessible from https://cs1.ucc.ie/~doh2/cgi-bin/lab7/late.html

Recently lost access to UCC Database due to graduation so certain serverside functionalities have temporarily been removed.
