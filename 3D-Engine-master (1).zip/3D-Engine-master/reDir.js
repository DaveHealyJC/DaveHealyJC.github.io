

function reDir() {
	window.location = "http://cs1.ucc.ie/~doh2/cgi-bin/lab7/index.py";
	}
setTimeout("reDir()", 10000);

